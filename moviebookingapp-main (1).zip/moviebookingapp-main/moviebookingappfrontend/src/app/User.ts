export class User{
    loginId!:string
    email!:string
    firstName!:string
    lastname!:string
    password!:string
    confirmPassword!:string
    contactNumber!:string
}