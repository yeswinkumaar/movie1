export class ForgotPassword{
    constructor(
   public password:string='',
    public confirmPassword:string=''){

    }
}